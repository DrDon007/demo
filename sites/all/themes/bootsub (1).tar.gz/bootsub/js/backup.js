/* callback function*/
function callback_auto(){
 var options = {
    language: 'en-GB',
    componentRestrictions: {country: ["in"]}
 };

var input1 = document.getElementById("edit-submitted-origin-city-api");
var autocomplete1 = new google.maps.places.Autocomplete(input1, options);

var input2 = document.getElementById("edit-submitted-destination-api");
var autocomplete2 = new google.maps.places.Autocomplete(input2, options);

}
/*
* start of main document function 
*/
jQuery(document).ready(function($){

/**
 *  callback form counter
 **/
function callcount(){
    var timer2 = "1:59";
    interval = setInterval(function() {
      var timer = timer2.split(':');
      //by parsing integer, I avoid all extra string processing
      var minutes = parseInt(timer[0], 10);
      var seconds = parseInt(timer[1], 10);
      --seconds;
      minutes = (seconds < 0) ? --minutes : minutes;
      if (minutes < 0) clearInterval(interval);
      seconds = (seconds < 0) ? 59 : seconds;
      seconds = (seconds < 10) ? '0' + seconds : seconds;
      //minutes = (minutes < 10) ?  minutes : minutes;
      $('.countdown').html(minutes + ':' + seconds);
      timer2 = minutes + ':' + seconds;
        //console.log("timer2 = "+timer2);
      if(timer2 === '0:00'){
          //$('.countdown').removeClass('countdown');
          clearTimeout(interval);
          /*setTimeout(function(){
              $('.webform-component--timer div').addClass('countdown');
          },2000);*/
          
          
      }
      if(timer2 === '1:00'){
          $('#nav-myForm .resend-link').show();
      }
    }, 1000);
    
}

/**
 *  main submit button disable
 **/
 $("#enquiry-form-2019 .form-actions .form-submit").attr("disabled", true);
 
$('#nav-myForm .edit-number, #nav-myForm .otp, #nav-myForm .submit-btn').hide();

$('#nav-myForm #send-otp').click(function(e){
    e.preventDefault();
    if($("#nav-myForm .callback-form-number").val().length === 10){
        localStorage.removeItem("number");
        $('#nav-myForm .timer div').addClass('countdown');
        $('#nav-myForm .name, #nav-myForm .contact-number, #nav-myForm .send-otp-btn').hide();
        $('#nav-myForm .edit-number, #nav-myForm .otp, #nav-myForm .submit-btn,  #nav-myForm .timer').show();
        var number = $('#nav-myForm .contact-number .callback-form-number').val();
        $('#nav-myForm .edit-number .number-text').text(number);
        number = $('#nav-myForm .callback-form-number').val();
        localStorage.setItem('number', number);
        $('#nav-myForm .submit-btn .resend-link').hide();
        var time = $('#nav-myForm .timer div').text();
        callcount();
        setTimeout(function(){
       
        sendOtp();
        
        }, 1000);
    }else{
        alert('Your Number is Invalid');
    }
});

$('#nav-myForm .submit-btn .resend-link').click(function(){
    $('#nav-myForm .submit-btn .resend-link').hide();
    button_count++;
    //console.log("button_count = "+button_count);
    if(button_count == 2){
        $('#nav-myForm .submit-btn .resend-link').removeClass('resend-link');
    }
    var a = $('#nav-myForm .number-text').text();
    //var rand = $.cookie('last_otp');
    //console.log(a+'  '+rand)
    resendOtp();
    //console.log('clicked pre-submit button');
    $('#nav-myForm .countdown').removeClass('countdown');
    $('#nav-myForm .timer div').addClass('countdown');

    clearTimeout(interval);
    callcount();
    
});

$('#nav-myForm .edit-number .number-edit').click(function(e){
    clearTimeout(interval);
    $('#nav-myForm .name, #nav-myForm .contact-number, #nav-myForm .send-otp-btn').show();
    $('#nav-myForm .edit-number, #nav-myForm .otp, #nav-myForm .submit-btn, #nav-myForm .timer').hide();
    
});
$('#nav-myForm .submit-btn #submit').click(function(e){
    e.preventDefault();
    var c = $('#nav-myForm .timer div').text();
    console.log("Timer Count= "+c);
    
    if(c  === "0:00"){
        alert('Your OTP has been Expired');
        
    }
    else{
        var otp = $('#nav-myForm .otp .form-otp').val();
        localStorage.setItem('form-otp', otp);
        var name = $('#nav-myForm .callback-form-name').val(); 
        localStorage.setItem('your-name', name);
        var number = $('#nav-myForm .callback-form-number').val();
        localStorage.setItem('number', number);
        varifyOtp();
        setTimeout(function(){
        var up = localStorage.getItem('sucess');
        if(up === 'currect'){
            console.log('varify complete');
            //console.log('inside to delete file');
            deleteOtp();
           // $('#enquiry-form-2019 .form-actions .form-submit').click();
           alert('Submitted Successfully');
           saveDatabase();
          window.location.href = "https://pmprime.rewelr.com/";
        
        }else{
        alert('OTP Not Matched');

        }
        },999);
    }
});
    

/**
 *   get the path variable 
 **/
var path_v = window.location.origin; 
//console.log('the path origin = '+ path_v);

/**
 *  add library for custom and cookie 
 **/
$('head').append('<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA3DGvhMK3wa14ZHJIbvB85gfn33RD18g4&libraries=places&callback=callback_auto"></script>');
var geocoder;

/* calculate the distance using google map api */
/* on click to next page */
$('#enquiry-form-2019 .dummy-btn').click(function(e){
  e.preventDefault();  
});

function saveDatabase(){
    var name = localStorage.getItem('your-name');
    var number = localStorage.getItem('number');
    var otp = localStorage.getItem('form-otp');
    
    var dataString = {"name": name, "number": number, "otp": otp};
    
    $.ajax({
        type:"POST",
        url: path_v+"/cphp/callback-form.php",
        data: dataString,
        success: function(data){
            console.log(data);
        }
    });
}



$('#enquiry-form-2019 #front_button').on("click", function(e){
e.preventDefault();
if($('#enquiry-form-2019 #edit-submitted-origin-city-api').val() !== ''){
    //for destination adress
    if($('#enquiry-form-2019 #edit-submitted-destination-api').val() !== ''){
        //origin city
        if($('#enquiry-form-2019 #edit-submitted-origin-city').val() === ''){
            alert('Sorry, Our Services Are Not Available In Selected Area');
        }else{
         var origin = $('#enquiry-form-2019 #edit-submitted-origin-city-api').val();//localStorage.getItem('from');//$('#from_places').val();
        var destination = $('#enquiry-form-2019 #edit-submitted-destination-api').val();//localStorage.getItem('to');//$('#to_places').val();
        var service = new google.maps.DistanceMatrixService();
        service.getDistanceMatrix(
        {
            origins: [origin],
            destinations: [destination],
            travelMode: google.maps.TravelMode.DRIVING,
            //unitSystem: google.maps.UnitSystem.IMPERIAL, // miles and feet.
            unitSystem: google.maps.UnitSystem.metric, // kilometers and meters.
            avoidHighways: false,
            avoidTolls: false
        }, callback);
        
        setTimeout(function(){ 
        //hasClass();
        var distance_f1 = $('#enquiry-form-2019 #edit-submitted-distance-api').val();
        var dc = 1.5;
        localStorage.setItem('distance_f1', distance_f1);
        localStorage.setItem('dc', dc);
        //console.log(localStorage.getItem('distance_f1')+' DC '+localStorage.getItem('dc'));
        
        var distance = $('#enquiry-form-2019 #edit-submitted-distance-api').val();
        if( distance !== ''){    
        $('#enquiry-form-2019 .webform-component--origin-city-api, #enquiry-form-2019 .webform-component--current-location, #enquiry-form-2019 .webform-component--origin-city, #enquiry-form-2019 .webform-component--destination-api, #enquiry-form-2019 .webform-component--distance-api, #enquiry-form-2019 #front_button, #enquiry-form-2019 .webform-component--moving-type, #enquiry-form-2019 .webform-component--distance-api').hide();
        $('#enquiry-form-2019 .webform-component--page-break-btn1').show();
        
            
            if( distance > 100){
              //  console.log('OutSide City');
                $('#enquiry-form-2019 #edit-submitted-moving-type-2').click();
                var ddc = 5000;
                localStorage.setItem('ddc',ddc);
               // console.log(localStorage.getItem('ddc'));
            }
            if(distance <100){
               // console.log('Within City');
                $('#enquiry-form-2019 #edit-submitted-moving-type-1').click();
                var ldd = 150;
                localStorage.setItem('ldd',ldd);
                //console.log(localStorage.getItem('ldd'));
            }
            }else{
                alert('Something Went Wrong Please Re-enter Your Location');
            }

        },1699);  
        }
    }
    else{
        alert('Please Enter Your Destination Address');
    }
    

}else{
    alert('Please Enter Your Origin Address');
}

});



//pass this callback function in url
function callback(response, status) {
    if (status != google.maps.DistanceMatrixStatus.OK) {
        //console.log('hoche na');
    }else{
        var origin = response.originAddresses[0];
        var destination = response.destinationAddresses[0];
        if (response.rows[0].elements[0].status === "ZERO_RESULTS") {
            $('#result').html("Better get on a plane. There are no roads between "  + origin + " and " + destination);
        } else {
            var distance = response.rows[0].elements[0].distance;
            var duration = response.rows[0].elements[0].duration;
            //console.log(response.rows[0].elements[0].distance);
            var distance_in_kilo = distance.value / 1000; // the kilom
            var distance_in_mile = distance.value / 1609.34; // the mile
            var duration_text = duration.text;
            var duration_value = duration.value;
            //console.log('destince is = '+distance_in_kilo.toFixed(2));
            $('#enquiry-form-2019 .webform-component--distance-api .form-control').val(distance_in_kilo.toFixed(2));

        }
     }
}    




//onclick get your current location
//$('.webform-component--current-location').one("mousemove",function(){
$('#enquiry-form-2019 .current-location').click(function(e){
    e.preventDefault();
//Get the latitude and the longitude;
  if (navigator.geolocation) {
      geocoder = new google.maps.Geocoder();
    navigator.geolocation.getCurrentPosition(successFunction, errorFunction);
} 

function errorFunction(){
    console.log("Geocoder failed");
}

function codeLatLng(lat, lng) {
    var latlng = new google.maps.LatLng(lat, lng);
    geocoder.geocode({'latLng': latlng}, function(results, status) {
      if (status == google.maps.GeocoderStatus.OK) {
      //console.log(results);
        if (results[1]) {
         //formatted address
         var current = results[0].formatted_address;
         //console.log(current);
         localStorage.setItem('get_current_location', current);
        //find country name
            for (var i=0; i<results[0].address_components.length; i++) {
            for (var b=0;b<results[0].address_components[i].types.length;b++) {

            //there are different types that might hold a city admin_area_lvl_1 usually does in come cases looking for sublocality type will be more appropriate
            if (results[0].address_components[i].types[b] == "administrative_area_level_1") {
                //this is the object you are looking for
                city= results[0].address_components[i];
                //console.log(city);
                //var location = localStorage.getItem('get_current_location');
                $('#enquiry-form-2019 #edit-submitted-origin-city-api').val(current);
                break;
                
            }
        }
    }
} 
else{
    alert("No Results Found");
    }
} else{
        alert("Geocoder failed due to: " + status);
      }
});
}

function successFunction(position) {
    var lat = position.coords.latitude;
    var lng = position.coords.longitude;
    codeLatLng(lat, lng);
}

});


/** filter the city name and get only match value**/
$('#enquiry-form-2019 #front_button').on('mouseenter',function(){
    
var str = $('#enquiry-form-2019 #edit-submitted-origin-city-api').val();    
arr = str.split(',');
strFile = arr[arr.length-3];
//console.log("new city function value = "+strFile );

var pat = /Bengaluru|Bangalore|BANGALORE|bangalore|Pune|PUNE|pune|Hyderabad|HYDERABAD|hyderabad|Chennai|chennai|CHENNAI|Mumbai|mumbai|MUMBAI|Navi Mumbai|navi mumbai|NAVI MUMBAI|Thane|THANE|thane|Cochin|COCHIN|cochin|Delhi|DELHI|delhi|Noida|noida|NOIDA|Gurgaon|GURGAON|gurgaon|Gurugram|Faridabad|FARIDABAD|faridabad|Ghaziabad|GHAZIABAD|ghaziabad|Ahmedabad|AHMEDABAD|ahmedabad|Jaipur|jaipur|JAIPUR|Kanpur|KANPUR|kanpur|Kolkata|kolkata|KOLKATA|Lucknow|lucknow|LUCKNOW|Nagpur|nagpur|NAGPUR|Surat|surat|SURAT|Pimpri-Chinchwad|Pimpri/m;
var res = strFile.match(pat);



$('#enquiry-form-2019 #edit-submitted-origin-city').val(res);

//console.log(str+' = '+res);

/* bengaluru to bangalore */
if($('#enquiry-form-2019 #edit-submitted-origin-city').val() == 'Bengaluru'){
    var str1 = $('#edit-submitted-origin-city').val();
    var txt = str1.replace('Bengaluru', 'Bangalore');
    $('#edit-submitted-origin-city').val(txt);
    //console.log(str1+'='+txt);
}

/* Gurugram to Gurgaon */
if($('#enquiry-form-2019 #edit-submitted-origin-city').val() == 'Gurugram'){
    var str2 = $('#edit-submitted-origin-city').val();
    var txt2 = str2.replace('Gurugram', 'Gurgaon');
    $('#edit-submitted-origin-city').val(txt2);
    //console.log(str2+'='+txt2);
}

if($('#enquiry-form-2019 #edit-submitted-origin-city').val() == 'Pimpri-Chinchwad'){
    var str3 = $('#edit-submitted-origin-city').val();
    var txt3 = str3.replace('Pimpri-Chinchwad', 'pune');
    $('#edit-submitted-origin-city').val(txt3);
    //console.log(str2+'='+txt2);
}
if($('#enquiry-form-2019 #edit-submitted-origin-city').val() == 'Pimpri'){
    var str4 = $('#edit-submitted-origin-city').val();
    var txt4 = str4.replace('Pimpri', 'pune');
    $('#edit-submitted-origin-city').val(txt4);
    //console.log(str2+'='+txt2);

}



});
 
/**
* counter for expair otp
**/
   
function timercount(){
    var timer2 = "1:59";
    interval = setInterval(function() {
      var timer = timer2.split(':');
      //by parsing integer, I avoid all extra string processing
      var minutes = parseInt(timer[0], 10);
      var seconds = parseInt(timer[1], 10);
      --seconds;
      minutes = (seconds < 0) ? --minutes : minutes;
      if (minutes < 0) clearInterval(interval);
      seconds = (seconds < 0) ? 59 : seconds;
      seconds = (seconds < 10) ? '0' + seconds : seconds;
      //minutes = (minutes < 10) ?  minutes : minutes;
      $('.countdown').html(minutes + ':' + seconds);
      timer2 = minutes + ':' + seconds;
        //console.log("timer2 = "+timer2);
      if(timer2 === '0:00'){
          //$('.countdown').removeClass('countdown');
          clearTimeout(interval);
          /*setTimeout(function(){
              $('.webform-component--timer div').addClass('countdown');
          },2000);*/
          
          
      }
      if(timer2 === '1:00'){
          $('#enquiry-form-2019 .resend-link').show();
      }
    }, 1000);
    
}

/**
 *  send otp button 
 **/
$('#enquiry-form-2019 #submit_otp').on('click',function(){
     button_count=0;
if($('#enquiry-form-2019 #edit-submitted-your-name').val() !== ''){
    if($('#enquiry-form-2019 #edit-submitted-number').val() !== ''){
        if($("#enquiry-form-2019 #edit-submitted-number").val().length === 10){
        if((localStorage.getItem('email-valid') === "valid") || ($('#enquiry-form-2019 .webform-component--email .form-control').val() === '')){
        console.log('email id valid');
        //$('#pre-submit').click(function(){
            var a = $('#enquiry-form-2019 #edit-submitted-number').val();
            //console.log(a);
            localStorage.setItem('number', a);
            $('#enquiry-form-2019 .number-text').text(a);
            $('#enquiry-form-2019 .webform-component--your-name, #enquiry-form-2019 .webform-component--email, #enquiry-form-2019 .webform-component--number, #enquiry-form-2019 .webform-component--pre-submit, #enquiry-form-2019 .webform-component--page-break-btn5, #enquiry-form-2019 .webform-component--credit-points').hide();
            $('#enquiry-form-2019 .webform-component--otp, #enquiry-form-2019 .number-edit, #enquiry-form-2019 .number-text, #enquiry-form-2019 .webform-component--timer, #enquiry-form-2019 .submit-button, #enquiry-form-2019 .webform-component--resend, #enquiry-form-2019 .webform-component--edit').show();
            $('#enquiry-form-2019 .resend-link').hide();
            //$('.submit-button').show();
           // var a = 1;
            sendOtp();
            emailSend();
            clearTimeout(interval);
            timercount();
        
            }else{
                alert('Please Enter a valid Email ID');
            
            }      
       }else{
           alert('Your number is Invalid');
        } 
    }else{
        alert('Please Enter Your Number');
    }
    }else{
        alert('Please Enter Your Name');
        
        
    }

});    

/*
* resend button validation 
*/
var interval;
var button_count=0;
$('#enquiry-form-2019 .resend-link').click(function(){
    $('.resend-link').hide();
    button_count++;
    //console.log("button_count = "+button_count);
    if(button_count == 2){
        $('#enquiry-form-2019 .webform-component--resend .resend-link').removeClass('resend-link');
    }
    var a = $('#enquiry-form-2019 .number-text').text();
    //var rand = $.cookie('last_otp');
    //console.log(a+'  '+rand)
    resendOtp();
    //console.log('clicked pre-submit button');
    $('#enquiry-form-2019 .countdown').removeClass('countdown');
    $('#enquiry-form-2019 .webform-component--timer div').addClass('countdown');

    clearTimeout(interval);
    timercount();
    
});

$('#enquiry-form-2019 .webform-component--edit .number-edit').click(function(){
    clearTimeout(interval);
    deleteOtp();
    $('#enquiry-form-2019 .webform-component--timer').hide();
    $('#enquiry-form-2019 .webform-component--credit-points, #enquiry-form-2019 .webform-component--your-name, #enquiry-form-2019 .webform-component--email, #enquiry-form-2019 .webform-component--number, #enquiry-form-2019 .webform-component--pre-submit, #enquiry-form-2019 .webform-component--page-break-btn5, #enquiry-form-2019 .webform-component--credit-points').show();
    $('#enquiry-form-2019 .webform-component--otp, #enquiry-form-2019 .number-edit, #enquiry-form-2019 .number-text, #enquiry-form-2019 .webform-component--resend, #enquiry-form-2019 .webform-component--edit').hide();
    $('#enquiry-form-2019 .submit-button, #enquiry-form-2019 .resend-link').hide();
    $('#enquiry-form-2019 .webform-component--resend span a').addClass('resend-link');
    localStorage.removeItem('number');
    $('#enquiry-form-2019 .resend-link').hide();
    
});

$('#enquiry-form-2019 .submit-button').click(function(e){
    e.preventDefault();
    var c = $('.webform-component--timer div').text();
    console.log("Timer Count= "+c)
    
    if(c  === "0:00"){
        alert('OTP has been Expired');
        
    }
    else{
        var otp = $('.webform-component--otp .form-control').val();
        localStorage.setItem("form-otp", otp);
        varifyOtp();
        setTimeout(function(){
        var up = localStorage.getItem('sucess');
        if(up === 'currect'){
            console.log('varify complete');
            //console.log('inside to delete file');
            deleteOtp();
            //$('#enquiry-form-2019 .form-actions .form-submit').click();
            $('#enquiry-form-2019 .webform-client-form').submit();
        
        }else{
        alert('OTP not Matched');

        }
        },999);
    }
});

$('#enquiry-form-2019 #edit-submitted-service-quality').change(function(){
    $('#enquiry-form-2019 .page_break_next_btn3').click();
});

$('#enquiry-form-2019 #edit-submitted-within-country-shifting-type, #enquiry-form-2019 #edit-submitted-within-city-shifting-type').change(function(){
    $('#enquiry-form-2019 .page_break_next_btn1').click();
});
 
/**
 *   button function
**/
$('#enquiry-form-2019 .webform-component--page-break-btn1, #enquiry-form-2019 .webform-component--page-break-btn2, #enquiry-form-2019 .webform-component--page-break-btn3, #enquiry-form-2019 .webform-component--page-break-btn4, #enquiry-form-2019 .webform-component--page-break-btn5, #enquiry-form-2019 .webform-component--pre-submit, #enquiry-form-2019 #edit-webform-ajax-submit-2, #enquiry-form-2019 .webform-component--within-country-shifting-type, #enquiry-form-2019 .webform-component--within-city-shifting-type, #enquiry-form-2019 .submit-button, #enquiry-form-2019 .resend-link, #enquiry-form-2019 .number-edit, #enquiry-form-2019 .webform-component--page-5, #enquiry-form-2019 .form-actions').hide();
$('#enquiry-form-2019 .webform-component--service-quality, #enquiry-form-2019 .webform-component--open-calendar, #enquiry-form-2019 .webform-component--datepicker-date, #enquiry-form-2019 .webform-component--your-name, #enquiry-form-2019 .webform-component--email, #enquiry-form-2019 .webform-component--number, #enquiry-form-2019 .webform-component--otp, #enquiry-form-2019 .webform-component--home-size, #enquiry-form-2019 .webform-component--shifting-size, #enquiry-form-2019 .webform-component--vehicle-type, #enquiry-form-2019 .webform-component--office-size').hide();

$('#enquiry-form-2019 .page_break_back_btn2').click(function(e){
    e.preventDefault();
var city = localStorage.getItem('city');
var shifting = localStorage.getItem('shifting_type');
    if(city === 'Outside City'){
        $('#enquiry-form-2019 .webform-component--within-country-shifting-type').show();
    }if(city === 'Within City'){
        $('#enquiry-form-2019 .webform-component--within-city-shifting-type').show();
    }
    if(shifting === 'Household Goods'){
        $('#enquiry-form-2019 .webform-component--home-size').hide();
    }
    if( shifting === 'Household + Vehicle'){
        $('#enquiry-form-2019 .webform-component--home-size, #enquiry-form-2019 .webform-component--vehicle-type').hide();
    }
    if(shifting === 'Vehicle Only'){
        $('#enquiry-form-2019 .webform-component--vehicle-type').hide();
    }
    if(shifting === 'Office Items'){
        $('.webform-component--office-size').hide();
    }
    $('#enquiry-form-2019 .webform-component--shifting-size, #enquiry-form-2019 .webform-component--page-break-btn2').hide();
    $('#enquiry-form-2019 .webform-component--page-break-btn1').show();
});

$('#enquiry-form-2019 .page_break_next_btn2').on('click',function(e){
    e.preventDefault();
    var vehicle = localStorage.getItem('e_f1');
    //console.log(vehicle);
    var shifting = localStorage.getItem('shifting_type');
    if( shifting === 'Household Goods'){
        if($('input:radio[name="submitted[home_size]"]').is(':checked') && $('input:radio[name="submitted[shifting_size]"]').is(':checked')){
            //console.log('checked household + shifting size');
                $('#enquiry-form-2019 .webform-component--page-break-btn2').hide();
                $('#enquiry-form-2019 .webform-component--page-break-btn3, #enquiry-form-2019 .webform-component--service-quality').show();
                $('#enquiry-form-2019 .webform-component--home-size, #enquiry-form-2019 .webform-component--shifting-size').hide();
            
        }else{
            alert('Please select Household and Shifthing Size');
        }
    }
    if( shifting === 'Household + Vehicle'){
        if($('input:radio[name="submitted[home_size]"]').is(':checked') && $('input:radio[name="submitted[shifting_size]"]').is(':checked') && $('.webform-component--vehicle-type .form-checkbox').is(':checked')){
            //console.log('checked household + shifting size + vehicle selected');
                $('#enquiry-form-2019 .webform-component--page-break-btn2').hide();
                $('#enquiry-form-2019 .webform-component--page-break-btn3, #enquiry-form-2019 .webform-component--service-quality').show();
                $('#enquiry-form-2019 .webform-component--home-size, #enquiry-form-2019 .webform-component--shifting-size, #enquiry-form-2019 .webform-component--vehicle-type').hide();

        }else{
            alert('Please select Household, Shifthing Size and Vehicle Types');
        }
    }
    if( shifting === 'Vehicle Only'){
        if($('.webform-component--vehicle-type .form-checkbox').is(':checked')){
            //console.log('vehicle selected');
            //$('.next').click(function(){
                $('#enquiry-form-2019 .webform-component--page-break-btn2').hide();
                $('#enquiry-form-2019 .webform-component--page-break-btn3, #enquiry-form-2019 .webform-component--service-quality').show();
                $('#enquiry-form-2019 .webform-component--vehicle-type').hide();
            //});
        }else{
            alert('Please Select Vehicle Types');
        }
    }
    if( shifting === 'Office Items'){
        if($('input:radio[name="submitted[office_size]"]').is(':checked') && $('input:radio[name="submitted[shifting_size]"]').is(':checked')){
            console.log('checked office item + shifting size');
            $('#enquiry-form-2019 .webform-component--page-break-btn2').hide();
            $('#enquiry-form-2019 .webform-component--page-break-btn3, #enquiry-form-2019 .webform-component--service-quality').show();
            $('#enquiry-form-2019 .webform-component--office-size, #enquiry-form-2019 .webform-component--shifting-size').hide();
        }else{
            alert('Please select Office Item and Shifthing Size');
       }
    }
});

$('#enquiry-form-2019 .page_break_next_btn3').on('click', function(e){
e.preventDefault();
   if($('input:radio[name="submitted[service_quality]"]').is(':checked')){
        $('#enquiry-form-2019 .webform-component--page-break-btn3').hide();
        $('#enquiry-form-2019 .webform-component--page-break-btn4').show();
        $('#enquiry-form-2019 .webform-component--service-quality').hide();
        $('#enquiry-form-2019 .webform-component--moving-date, #enquiry-form-2019 .webform-component--open-calendar').show();
   }else{
       alert('Please Select Service Quality');
   } 
});

$('#enquiry-form-2019 .page_break_back_btn3').click(function(e){
e.preventDefault();
    var city = localStorage.getItem('city');
    var shifting = localStorage.getItem('shifting_type');
    if(shifting === 'Household Goods'){
        $('#enquiry-form-2019 .webform-component--home-size').show();
        $('#enquiry-form-2019 .webform-component--shifting-size, #enquiry-form-2019 .webform-component--page-break-btn2').show();
    }
    if( shifting === 'Household + Vehicle'){
        $('#enquiry-form-2019 .webform-component--home-size, #enquiry-form-2019 .webform-component--vehicle-type').show();
        $('#enquiry-form-2019 .webform-component--shifting-size, #enquiry-form-2019 .webform-component--page-break-btn2').show();
    }
    if(shifting === 'Vehicle Only'){
        $('#enquiry-form-2019 .webform-component--vehicle-type').show();
        $('#enquiry-form-2019 .webform-component--shifting-size').hide();
    }
    if(shifting === 'Office Items'){
        $('#enquiry-form-2019 .webform-component--office-size').show();
        $('#enquiry-form-2019 .webform-component--shifting-size, #enquiry-form-2019 .webform-component--page-break-btn2').show();
    }
    
    $('#enquiry-form-2019 .webform-component--page-break-btn2').show();
    $('#enquiry-form-2019 .webform-component--page-break-btn3, #enquiry-form-2019 .webform-component--service-quality').hide();
});

$('#enquiry-form-2019 .page_break_next_btn1').on('click',function(e){
    e.preventDefault();
    var city = localStorage.getItem('city');
    var shifting = localStorage.getItem('shifting_type');
        if(city === 'Outside City'){
            if ($('input:radio[name="submitted[within_country_shifting_type]"]').is(':checked')) {
                $('#enquiry-form-2019 .webform-component--page-break-btn1').hide();
                $('#enquiry-form-2019 .webform-component--within-country-shifting-type').hide();
                if(shifting === 'Household Goods'){
                    $('#enquiry-form-2019 .webform-component--home-size').show();
                    $('#enquiry-form-2019 .webform-component--shifting-size, #enquiry-form-2019 .webform-component--page-break-btn2').show();
                }
                if( shifting === 'Household + Vehicle'){
                    
                    $('#enquiry-form-2019 .webform-component--home-size, #enquiry-form-2019 .webform-component--vehicle-type').show();
                    $('#enquiry-form-2019 .webform-component--shifting-size, #enquiry-form-2019 .webform-component--page-break-btn2').show();
                }
                if(shifting === 'Vehicle Only'){
                    
                    $('#enquiry-form-2019 .webform-component--vehicle-type').show();
                    $('#enquiry-form-2019 .webform-component--page-break-btn2').show();
                    $('#enquiry-form-2019 .webform-component--shifting-size').hide();
                }
                if(shifting === 'Office Items'){
                    $('#enquiry-form-2019 .webform-component--office-size').show();
                    $('#enquiry-form-2019 .webform-component--shifting-size, #enquiry-form-2019 .webform-component--page-break-btn2').show();
                }
            }else{
                alert('Please select Your Shifting Type');
            }
        }
        if(city === 'Within City'){
            if($('input:radio[name="submitted[within_city_shifting_type]"]').is(':checked')){
                $('#enquiry-form-2019 .webform-component--page-break-btn1').hide();
                $('#enquiry-form-2019 .webform-component--within-city-shifting-type').hide();
                if(shifting === 'Household Goods'){
                    
                    $('#enquiry-form-2019 .webform-component--home-size').show();
                    $('#enquiry-form-2019 .webform-component--shifting-size, #enquiry-form-2019 .webform-component--page-break-btn2').show();
                }
                if(shifting === 'Office Items'){
                    
                    $('#enquiry-form-2019 .webform-component--office-size').show();
                    $('#enquiry-form-2019 .webform-component--shifting-size, #enquiry-form-2019 .webform-component--page-break-btn2').show();
                }
            }
            else{
                alert('Please select Your Shifting type');
            }
        }
});

$('#enquiry-form-2019 .page_break_back_btn1').click(function(e){
     e.preventDefault();
    $('#enquiry-form-2019 .webform-component--moving-type').find('input').prop('checked', false); 
    $('#enquiry-form-2019 .webform-component--origin-city-api, #enquiry-form-2019 .webform-component--current-location, #enquiry-form-2019 .webform-component--destination-api, #enquiry-form-2019 #front_button').show();
    $('#enquiry-form-2019 .webform-component--page-break-btn2').hide();
    $('#enquiry-form-2019 .webform-component--home-size, #enquiry-form-2019 .webform-component--shifting-size, #enquiry-form-2019 .webform-component--vehicle-type, #enquiry-form-2019 .webform-component--within-country-shifting-type, #enquiry-form-2019 .webform-component--within-city-shifting-type, #enquiry-form-2019 .webform-component--outside-country-shifting-type, #enquiry-form-2019 .webform-component--office-size, #enquiry-form-2019 .webform-component--page-break-btn1').hide();
});

$('#enquiry-form-2019 .page_break_next_btn4').click(function(e){
    e.preventDefault();
    if($('#enquiry-form-2019 .webform-component--moving-date .form-control').val() === ''){
      alert('Select Your Moving date');  
    }else{
    $('#enquiry-form-2019 .webform-component--your-name, #enquiry-form-2019 .webform-component--email, #enquiry-form-2019 .webform-component--number, #enquiry-form-2019 .webform-component--pre-submit, #enquiry-form-2019 .webform-component--credit-points').show();
    $('#enquiry-form-2019 .webform-component--moving-date, #enquiry-form-2019 .webform-component--open-calendar').hide();
    $('#enquiry-form-2019 .webform-component--page-break-btn4').hide();
    $('#enquiry-form-2019 .webform-component--page-break-btn5').show();
    }
});
$('#enquiry-form-2019 .page_break_back_btn4').click(function(e){
    e.preventDefault();
    $('#enquiry-form-2019 .webform-component--page-break-btn4').hide(); 
    $('#enquiry-form-2019 .webform-component--page-break-btn3').show();
    $('#enquiry-form-2019 .webform-component--moving-date, #enquiry-form-2019 .webform-component--open-calendar').hide();
    $('#enquiry-form-2019 .webform-component--service-quality').show();
});
$('#enquiry-form-2019 .page_break_back_btn5').click(function(e){
     e.preventDefault();
    $('#enquiry-form-2019 .webform-component--page-break-btn5').hide(); 
    $('#enquiry-form-2019 .webform-component--page-break-btn4').show();
    $('#enquiry-form-2019 .webform-component--moving-date, #enquiry-form-2019 .webform-component--open-calendar').show(); 
    $('#enquiry-form-2019 .webform-component--credit-points, #enquiry-form-2019 .webform-component--your-name, #enquiry-form-2019 .webform-component--email, #enquiry-form-2019 .webform-component--number, #enquiry-form-2019 .webform-component--otp, #enquiry-form-2019 .webform-component--pre-submit, #enquiry-form-2019 .webform-component--credit-points').hide();
});
/**
 *  number field validation 
 **/
$("#enquiry-form-2019 #edit-submitted-number, .callback-form-number, #enquiry-form-2019 .webform-component--otp .form-control").keypress(function (e) {
     //if the letter is not digit then display error and don't type anything
     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        //display error message
        return false;
    }
});
/**
 *  name field validation 
 **/
$("#enquiry-form-2019 .webform-component--your-name .form-control, .callback-form-name").bind('keyup',function(){ 
    $(this).val( $(this).val().replace(/[^A-Z a-z]/g,'') ); 
});
/**
 *  email field validation 
 **/
$("#enquiry-form-2019 #edit-submitted-email").keyup(function(){
    var str = $('#enquiry-form-2019 #edit-submitted-email').val();
    var res = str.match(/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/);
    if(res === null){
        console.log("res ="+res)
        localStorage.removeItem('email-valid');
    }else{
        localStorage.setItem('email-valid', "valid");
    }
    
    
});
 
/**
 *  list for claculation
 **/
/* -VARIABLES- */
var within_city=0.8, 
outside_city=1.2, 
shifting_size_few_items=1.5,
shifting_size_all_items=2.6,
office_mini=4,
office_small=5,
office_standard=7,
office_big=9,
bhk1 =3.3,
bhk2=4,
bhk3=4.5,
bhk4=4.8,
villa=5.2;
                        //within city

$('#enquiry-form-2019 #edit-submitted-moving-type-1').click(function(){
    var a_f1 =within_city;
    localStorage.setItem('a_f1', a_f1);
    var city = $('#enquiry-form-2019 #edit-submitted-moving-type-1').val();
    localStorage.setItem('city', city);
    localStorage.removeItem('ddc');
});
                        //outside city
                        
$('#enquiry-form-2019 #edit-submitted-moving-type-2').click(function(){
    var a_f1 = outside_city;
    localStorage.setItem('a_f1', a_f1);
    var city = $('#enquiry-form-2019 #edit-submitted-moving-type-2').val();
    localStorage.setItem('city', city);
    localStorage.removeItem('lld');
});

 
 
                        //Shifting Size || Few Items
                        
$('#enquiry-form-2019 #edit-submitted-shifting-size-1').click(function(){
    var b_f1 = shifting_size_few_items;
    var shifting = $('#enquiry-form-2019 #edit-submitted-shifting-size-1').val();
    localStorage.setItem('shifting', shifting);
    localStorage.setItem('b_f1', b_f1);
});

                        //Shifting Size || All Items
                        
$('#enquiry-form-2019 #edit-submitted-shifting-size-2').click(function(){
    var b_f1 = shifting_size_all_items;
    var shifting = $('#enquiry-form-2019 #edit-submitted-shifting-size-2').val();
    localStorage.setItem('shifting', shifting);
    localStorage.setItem('b_f1', b_f1);
});

                        //Office Size || mini office
                        
$('#enquiry-form-2019 #edit-submitted-office-size-1').click(function(){
    var c_f1 = office_mini;
    var office = $('#enquiry-form-2019 #edit-submitted-office-size-1').val();
    localStorage.setItem('office', office);
    localStorage.setItem('c_f1', c_f1);
});

                        //Office Size || Small Office  
                        
$('#enquiry-form-2019 #edit-submitted-office-size-2').click(function(){
    var c_f1 = office_small;
    var office = $('#enquiry-form-2019 #edit-submitted-office-size-2').val();
    localStorage.setItem('office', office);
    localStorage.setItem('c_f1', c_f1);
});

                        //Office Size || Standard Office
                            
$('#enquiry-form-2019 #edit-submitted-office-size-3').click(function(){
    var c_f1 = office_standard;
    var office = $('#enquiry-form-2019 #edit-submitted-office-size-3').val();
    localStorage.setItem('office', office);
    localStorage.setItem('c_f1', c_f1);
});

                        //Office Size || Big Office
                        
$('#enquiry-form-2019 #edit-submitted-office-size-4').click(function(){
    var c_f1 = office_big;
    var office = $('#enquiry-form-2019 #edit-submitted-office-size-4').val();
    localStorage.setItem('office', office);
    localStorage.setItem('c_f1', c_f1);
});

                        //1bhk
$('#enquiry-form-2019 #edit-submitted-home-size-1').click(function(){
    var d_f1 = bhk1;
    var home = $('#enquiry-form-2019 #edit-submitted-home-size-1').val();
    localStorage.setItem('home', home);
    localStorage.setItem('d_f1', d_f1);
});
                        //2bhk
$('#enquiry-form-2019 #edit-submitted-home-size-2').click(function(){
    var d_f1 = bhk2;
    var home = $('#enquiry-form-2019 #edit-submitted-home-size-2').val();
    localStorage.setItem('home', home);
    localStorage.setItem('d_f1', d_f1);
});
                        //3bhk
$('#enquiry-form-2019 #edit-submitted-home-size-3').click(function(){
    var d_f1 = bhk3;
    var home = $('#enquiry-form-2019 #edit-submitted-home-size-3').val();
    localStorage.setItem('home', home);
    localStorage.setItem('d_f1', d_f1);
});
                        //4bhk
$('#enquiry-form-2019 #edit-submitted-home-size-4').click(function(){
    var d_f1 = bhk4;
    var home = $('#enquiry-form-2019 #edit-submitted-home-size-4').val();
    localStorage.setItem('home', home);
    localStorage.setItem('d_f1', d_f1);
});
                        //villa
$('#enquiry-form-2019 #edit-submitted-home-size-5').click(function(){
    var d_f1 = villa;
    var home = $('#enquiry-form-2019 #edit-submitted-home-size-5').val();
    localStorage.setItem('home', home);
    localStorage.setItem('d_f1', d_f1);
});
$('#enquiry-form-2019 .webform-component--vehicle-type').change(function(){
    localStorage.removeItem('e_f1');
    var t_v, f_v, uff;
    if($('#enquiry-form-2019 #edit-submitted-vehicle-type-1').is(':checked')){
        f_v = "6";
        localStorage.setItem('e_f1', f_v);
    }
    if($('#enquiry-form-2019 #edit-submitted-vehicle-type-2').is(':checked')){
        t_v = "3";
        localStorage.setItem('e_f1', t_v);
    }
    
   if($('#enquiry-form-2019 #edit-submitted-vehicle-type-2').is(':checked') && $('#enquiry-form-2019 #edit-submitted-vehicle-type-1').is(':checked')){
        uff = "9";
        localStorage.setItem('e_f1', uff);
    }
});
                        //service Economical
$('#enquiry-form-2019 #edit-submitted-service-quality-1').click(function(){
    var f_f1 = "1";
    var service = $('#enquiry-form-2019 #edit-submitted-service-quality-1').val();
    localStorage.setItem('service', service);
    localStorage.setItem('f_f1', f_f1);
    
});
                                //Premium
$('#enquiry-form-2019 #edit-submitted-service-quality-2').click(function(){
    var f_f1 = "1.2";
    var service = $('#enquiry-form-2019 #edit-submitted-service-quality-2').val();
    localStorage.setItem('service', service);
    localStorage.setItem('f_f1', f_f1);
});
/**
 *  the shifting type 
 **/
//shifting type
$('#enquiry-form-2019 #edit-submitted-within-city-shifting-type-1').click(function(){
    var shifting_type = $('#enquiry-form-2019 #edit-submitted-within-city-shifting-type-1').val();
    localStorage.setItem('shifting_type',shifting_type);

  
});
    
$('#enquiry-form-2019 #edit-submitted-within-city-shifting-type-2').click(function(){
    var shifting_type = $('#enquiry-form-2019 #edit-submitted-within-city-shifting-type-2').val();
    localStorage.setItem('shifting_type',shifting_type);

});

$('#enquiry-form-2019 #edit-submitted-within-country-shifting-type-1').click(function(){
    var shifting_type = $('#enquiry-form-2019 #edit-submitted-within-country-shifting-type-1').val();
    localStorage.setItem('shifting_type',shifting_type);
});

$('#edit-submitted-within-country-shifting-type-2').click(function(){
    var shifting_type = $('#enquiry-form-2019 #edit-submitted-within-country-shifting-type-2').val();
    localStorage.setItem('shifting_type',shifting_type);
});
    
$('#enquiry-form-2019 #edit-submitted-within-country-shifting-type-3').click(function(){
    var shifting_type = $('#enquiry-form-2019 #edit-submitted-within-country-shifting-type-3').val();
    localStorage.setItem('shifting_type',shifting_type);
});

$('#enquiry-form-2019 #edit-submitted-within-country-shifting-type-4').click(function(){
    var shifting_type = $('#enquiry-form-2019 #edit-submitted-within-country-shifting-type-4').val();
    localStorage.setItem('shifting_type',shifting_type);
});
/**
 *   remove the localStorage for calculation 
 **/
//remove the localStorage 
$('#enquiry-form-2019 #edit-submitted-outside-country-shifting-type-1').click(function(){
    localStorage.removeItem('v_f1');
    localStorage.removeItem('e_f1');
    localStorage.removeItem('c_f1');
});
$('#enquiry-form-2019 #edit-submitted-outside-country-shifting-type-2').click(function(){
    localStorage.removeItem('c_f1');
});
$('#enquiry-form-2019 #edit-submitted-outside-country-shifting-type-3').click(function(){
    localStorage.removeItem('c_f1');
    localStorage.removeItem('d_f1');
});
$('#enquiry-form-2019 #edit-submitted-outside-country-shifting-type-4').click(function(){
    localStorage.removeItem('v_f1');
    localStorage.removeItem('d_f1');
    localStorage.removeItem('e_f1');
});
$('#enquiry-form-2019 #edit-submitted-within-city-shifting-type-1').click(function(){
    localStorage.removeItem('c_f1');
});
$('#enquiry-form-2019 #edit-submitted-within-city-shifting-type-2').click(function(){
    localStorage.removeItem('d_f1');
});


/**
 *  claculation for the credit point
 **/
 /** the calculation for only vehicle **/
$('#enquiry-form-2019 #custom-datepicker, #enquiry-form-2019 .webform-component--moving-date').hover(function(){
if(localStorage.getItem('e_f1') !== null){
    var a_f1 = localStorage.getItem('a_f1');
    var e_f1 = localStorage.getItem('e_f1');
    var f_f1 = localStorage.getItem('f_f1');
    var DC = localStorage.getItem('dc');
    var LDD = localStorage.getItem('ldd');
    var DDC = localStorage.getItem('ddc');
    var DIS = localStorage.getItem('distance_f1');
    var v_f1 = parseFloat(a_f1)  * parseFloat(e_f1) * parseFloat(f_f1) * (parseFloat(DC)+parseFloat(DIS)/parseFloat(DDC));
    localStorage.setItem('v_f1', v_f1);
}
else{
    var v_f1 = 0;
}
    
});

/**
 *  calculation for all value 
 **/ 
/** claculation for all  data **/
$('#enquiry-form-2019 #submit_otp').on("mouseenter",function(){
if(localStorage.getItem('shifting_type') == 'Vehicle Only'){
    if(localStorage.getItem('e_f1') != null){
        var a_f1 = localStorage.getItem('a_f1');
        var e_f1 = localStorage.getItem('e_f1');
        var f_f1 = localStorage.getItem('f_f1');
        var DC = localStorage.getItem('dc');
        var LDD = localStorage.getItem('ldd');
        var DDC = localStorage.getItem('ddc');
        var DIS = localStorage.getItem('distance_f1');
        var v_f1 = parseFloat(a_f1)  * parseFloat(e_f1) * parseFloat(f_f1) * (parseFloat(DC)+parseFloat(DIS)/parseFloat(DDC));
        localStorage.setItem('v_f1', v_f1);
        console.log("after Claculation = "+v_f1);
        localStorage.setItem('credit_val', v_f1 );
    }
    else{
        var v_f1 = 0;
        
    }
}
else{
    var City_val = localStorage.getItem('City_val');
    if(City_val == 'Bangalore' || City_val == 'bangalore' | City_val == 'BANGALORE'){
        console.log('Bangalore');
        var city_variable = localStorage.getItem('Bangalore'); 
    }else if(City_val == 'Pune' || City_val == 'pune' || City_val == 'PUNE'){
        console.log('Pune');
        city_variable = localStorage.getItem('Pune');
    }else if(City_val == 'Mumbai' || City_val == 'mumbai' || City_val == 'MUMBAI'){
        console.log('Mumbai');
        city_variable = localStorage.getItem('Mumbai');
    }
    else if(City_val == 'Chennai' || City_val == 'chennai' || City_val == 'CHENNAI'){
        console.log('Chennai');
        city_variable = localStorage.getItem('Chennai');
    }
    else if(City_val == 'Hyderabad' || City_val == 'hyderabad' || City_val == 'HYDERABAD'){
        console.log('Hyderabad');
        city_variable = localStorage.getItem('Hyderabad');
    }
    else if(City_val == 'Navi Mumbai' || City_val == 'navi mumbai' || City_val == 'NAVI MUMBAI'){
        console.log('Navi_Mumbai');
        city_variable = localStorage.getItem('Navi_Mumbai');
    }
    else if(City_val == 'Thane' || City_val == 'thane' || City_val == 'THANE'){
        console.log('Thane');
        city_variable = localStorage.getItem('Thane');
    }
    else if(City_val == 'Delhi' || City_val == 'delhi'|| City_val == 'DELHI'){
        console.log('Delhi');
        city_variable = localStorage.getItem('Delhi');
    }else if(City_val == 'Gurgaon' || City_val == 'gurgaon' || City_val == 'GURUGAON'){
        console.log('Gurgaon');
        city_variable = localStorage.getItem('Gurgaon');
    }else if(City_val == 'Noida' || City_val == 'noida' || City_val == 'NOIDA'){
        console.log('Noida');
        city_variable = localStorage.getItem('Noida');
    }else if(City_val == 'Faridabad' || City_val == 'faridabad' || City_val == 'FARIDABAD'){
        console.log('Faridabad');
        city_variable = localStorage.getItem('Faridabad');
    }else if(City_val == 'Ghaziabad' || City_val == 'ghaziabad' || City_val == 'GHAZIABAD'){
        console.log('Ghaziabad');
        city_variable = localStorage.getItem('Ghaziabad');
    }
    else if(City_val == 'Ahmedabad' || City_val == 'ahmedabad' || City_val == 'AHMEDABAD'){
        console.log('Ahmedabad');
        city_variable = localStorage.getItem('Ahmedabad');
    }
    else if(City_val == 'Jaipur' || City_val == 'jaipur' || City_val == 'JAIPUR'){
        console.log('Jaipur');
        city_variable = localStorage.getItem('Jaipur');
    }
    else if(City_val == 'Cochin' || City_val == 'cochin' || City_val == 'COCHIN'){
        console.log('Cochin');
        city_variable = localStorage.getItem('Cochin');
    }
    else if(City_val == 'Kolkata' || City_val == 'kolkata' || City_val == 'KOLKATA'){
        console.log('Kolkata');
        city_variable = localStorage.getItem('Kolkata');
    }
    else if(City_val == 'Surat' || City_val == 'surat' || City_val == 'SURAT'){
        console.log('Surat');
        city_variable = localStorage.getItem('Surat');
    }
    else{
        console.log('Not Avilable');
        city_variable = 1;
    }
    if(localStorage.getItem('v_f1') != null ){
        var v_f1 = localStorage.getItem('v_f1');
    }else{
         var v_f1 = 0;
         
    }
    if(localStorage.getItem('a_f1') != null){
    var a_f1 = localStorage.getItem('a_f1');}
    else{
       var a_f1 = 1;
    }
    
    if(localStorage.getItem('b_f1') != null){
    var b_f1 = localStorage.getItem('b_f1');}
        else{
        var b_f1 = 1;
    }
    
    if(localStorage.getItem('c_f1') != null){
    var c_f1 = localStorage.getItem('c_f1');}
    else{
       var c_f1 = 1;
    }
    
    if(localStorage.getItem('d_f1') != null){
    var d_f1 = localStorage.getItem('d_f1');}
        else{
       var d_f1 = 1;
    }
    
    
    if(localStorage.getItem('f_f1') != null){
    var f_f1 = localStorage.getItem('f_f1');}
        else{
        f_f1 = 1;
    }
    
    var DC = localStorage.getItem('dc');
    var LDD = localStorage.getItem('ldd');
    var DDC = localStorage.getItem('ddc');
    var DIS = localStorage.getItem('distance_f1');
    
    
    if(LDD == null){

    var dist = parseFloat(DC)+(parseFloat(DIS)/parseFloat(DDC));
    var z1_f1 = parseFloat(d_f1) * parseFloat(dist) *parseFloat(f_f1) *parseFloat(a_f1) * parseFloat(b_f1) *parseFloat(c_f1) * parseFloat(city_variable) ;
    var z_f1 =  parseFloat(v_f1)+parseFloat(z1_f1);
    localStorage.setItem('zz', z_f1);
    console.log("after Claculation = "+z_f1);
    localStorage.setItem('credit_val', z_f1);
    

    }
    else{

    var dist = parseFloat(DC)+parseFloat(DIS)/parseFloat(LDD);
    var z_f1 = parseFloat(d_f1) * parseFloat(dist) *parseFloat(f_f1) *parseFloat(a_f1) * parseFloat(b_f1) *parseFloat(c_f1)* parseFloat(city_variable);
    localStorage.setItem('zz', z_f1);
    console.log("after Claculation = "+z_f1);
    localStorage.setItem('credit_val', z_f1 );
        
    }
}
});   

/**
 *   city variable 
 **/
/*_* ---------------get the city variable ---------------------------- *_*/

$('#enquiry-form-2019 #front_button').on('click',function(){ 
var city_val = $('#edit-submitted-origin-city').val();
localStorage.setItem('City_val', city_val);
var Bangalore=1,Pune=1,Mumbai=1,Chennai=1,Hyderabad=0.90,Navi_Mumbai=0.85,Thane=0.85,Delhi=0.85,Gurgaon=0.85,Noida=0.65,Faridabad=0.65,Ghaziabad=0.65,Ahmedabad=0.65,Jaipur=0.65,Kanpur=0.65,Cochin=0.65,Kolkata=0.65,Lucknow=0.65,Nagpur=0.65,Surat=0.65;  
localStorage.setItem('Bangalore', Bangalore);
localStorage.setItem('Chennai', Chennai);
localStorage.setItem('Pune', Pune);
localStorage.setItem('Hyderabad', Hyderabad);
localStorage.setItem('Mumbai', Mumbai);
localStorage.setItem('Navi_Mumbai', Navi_Mumbai);
localStorage.setItem('Thane', Thane);
localStorage.setItem('Cochin', Cochin);
localStorage.setItem('Delhi', Delhi);
localStorage.setItem('Noida', Noida);
localStorage.setItem('Gurgaon', Gurgaon);
localStorage.setItem('Faridabad', Faridabad);
localStorage.setItem('Ghaziabad', Ghaziabad);
localStorage.setItem('Ahmedabad', Ahmedabad);
localStorage.setItem('Jaipur', Jaipur);
localStorage.setItem('Kanpur', Kanpur);
localStorage.setItem('Kolkata', Kolkata);
localStorage.setItem('Lucknow', Lucknow);
localStorage.setItem('Nagpur', Nagpur);
localStorage.setItem('Surat', Surat);

});

/**
 *  clear all localStorage
 **/
/** clear the all localStorage **/
$('#enquiry-form-2019 #front_button').on('mouseenter',function(){
    localStorage.removeItem('a_f1');
    localStorage.removeItem('b_f1');
    localStorage.removeItem('c_f1');
    localStorage.removeItem('d_f1');
    localStorage.removeItem('e_f1');
    localStorage.removeItem('f_f1');
    localStorage.removeItem('v_f1');
});
/**
 *  clear the distance variable 
 **/
/* clear localhost */
$('#enquiry-form-2019 .current-location').on("click",function(){
    localStorage.removeItem('ldd');
    localStorage.removeItem('ddc');
});
$('#enquiry-form-2019 #edit-submitted-destination-api, #enquiry-form-2019 #edit-submitted-origin-city-api').change(function(){
    localStorage.removeItem('ldd');
    localStorage.removeItem('ddc');
    //console.log(localStorage.getItem('lld')+' '+localStorage.getItem('ddc'));
});
/**
 *   one click clear some particular localStorage 
 **/
//remove the localStorage 
$('#enquiry-form-2019 #edit-submitted-outside-country-shifting-type-1').click(function(){
    localStorage.removeItem('v_f1');
    localStorage.removeItem('e_f1');
    localStorage.removeItem('c_f1');
});
$('#enquiry-form-2019 #edit-submitted-outside-country-shifting-type-2').click(function(){
    localStorage.removeItem('c_f1');
});
$('#enquiry-form-2019 #edit-submitted-outside-country-shifting-type-3').click(function(){
    localStorage.removeItem('c_f1');
    localStorage.removeItem('d_f1');
});
$('#enquiry-form-2019 #edit-submitted-outside-country-shifting-type-4').click(function(){
    localStorage.removeItem('v_f1');
    localStorage.removeItem('d_f1');
    localStorage.removeItem('e_f1');
});
$('#enquiry-form-2019 #edit-submitted-within-city-shifting-type-1').click(function(){
    localStorage.removeItem('c_f1');
});
$('#enquiry-form-2019 #edit-submitted-within-city-shifting-type-2').click(function(){
    localStorage.removeItem('d_f1');
});
/**
 *  remove the all selecterd
 **/
 
$('#enquiry-form-2019 #edit-submitted-destination-api, #enquiry-form-2019 #edit-submitted-origin-city-api').change(function(){
    $('#enquiry-form-2019 .webform-component--within-country-shifting-type, #enquiry-form-2019 .webform-component--within-city-shifting-type, #enquiry-form-2019 .webform-component--service-quality').find('input').prop('checked', false); 
}); 
$('#enquiry-form-2019 .webform-component--within-country-shifting-type, #enquiry-form-2019 .webform-component--within-city-shifting-type').change(function(){
    console.log('all radio button unselected');
    $('#enquiry-form-2019 .webform-component--home-size, #enquiry-form-2019 .webform-component--vehicle-type, #enquiry-form-2019 .webform-component--shifting-size, #enquiry-form-2019 .webform-component--office-size').find('input').prop('checked', false); 
    $('#enquiry-form-2019 #edit-submitted-moving-date').val('');
     
});
$('#enquiry-form-2019 #front_button').on('click',function(){
console.log('clear');
$('#enquiry-form-2019 .webform-component--within-country-shifting-type, #enquiry-form-2019 .webform-component--within-city-shifting-type, #enquiry-form-2019 .webform-component--service-quality').find('input').prop('checked', false);

});

/**
*  send the otp uisng jQuery
**/
function sendOtp(){
    var number = localStorage.getItem('number');
    var dataString = {'number':number};
        
   $.ajax({
        type:"POST",
        url: path_v+'/otp/new_otp_send.php',
        data:dataString,
        success:function(data){
            console.log('otp is send to your mobile '+ number);
            //console.log(data);
        }
    });
}
/**
 *  resend Otp using jQuery
 **/
function resendOtp(){
    var number = localStorage.getItem('number');
    var dataString = {'number':number};
   $.ajax({
        type:"POST",
        url:path_v+'/otp/new_otp_resend.php',
        data:dataString,
        success:function(data){
          
        }
    });
    
}

/**
 *  varify function 
 **/
function varifyOtp(){
    var number = localStorage.getItem('number');
    var otp = localStorage.getItem('form-otp');//$('.webform-component--otp .form-control').val();
    var dataString = {"number":number, "rand":otp};
    $.ajax({
        type:"POST",
        url:path_v+"/otp/new_otp_varify.php",
        data: dataString,
        success: function(data){
            //console.log('number = '+number+" and rand = "+otp);
            localStorage.setItem('sucess', data);
        }
    });
}
/**
 *   delete function 
 **/
function deleteOtp(){
    var number = localStorage.getItem('number');
    var dataString = {"number":number};
    $.ajax({
        type:"POST",
        url:path_v+'/otp/new_otp_delete.php',
        data:dataString,
        success:function(data){
            console.log('done');
        }
    });
}
$('#enquiry-form-2019 .webform-component--otp .form-control').one("mouseleave", function(){
    console.log('after 5 min thet data will clear');
    setTimeout(function(){ 
    var number = localStorage.getItem('number');
    var dataString = {'number':number};
    $.ajax({
        type:"POST",
        url:path_v+"/otp/auto_clear.php",
        data:dataString,
        success: function(data){
            console.log(data);
        }
    });
    }, 5 * 60 * 1000);
});

function emailSend(){
        var creditpoint = $('#enquiry-form-2019 .webform-component--credit-points .form-control').val();
        var city = localStorage.getItem('city');
        
        var shiftingType = localStorage.getItem('shifting_type');
        
        var ShiftingSize = localStorage.getItem('shifting');
        
        var HomeSize = localStorage.getItem('home');
        
        var Vehicle = localStorage.getItem('vehicle');
        
        var office = localStorage.getItem('office');
        
        var ServiceQuality = localStorage.getItem('service');
        
        var origin_city = $('#enquiry-form-2019 .webform-component--origin-city .form-control').val();
        
        var MovingFrom = $('#enquiry-form-2019 .webform-component--origin-city-api .form-control').val();
        
        var MovingTo = $('#enquiry-form-2019 .webform-component--destination-api .form-control').val();
        
        var MovingDate = $('#enquiry-form-2019 .webform-component--moving-date .form-control').val();
        var distance = $('#enquiry-form-2019 .webform-component--distance-api .form-control').val();
        var email = $('#enquiry-form-2019 .webform-component--email .form-control').val();
        var name = $('#enquiry-form-2019 .webform-component--your-name .form-control').val();
        var number = $('#enquiry-form-2019 .webform-component--number .form-control').val();
        
        var dataString = {"city":city, "shiftingType":shiftingType, "office":office, "ShiftingSize":ShiftingSize, "HomeSize":HomeSize, "ServiceQuality":ServiceQuality, "origin_city":origin_city, "MovingFrom":MovingFrom, "MovingTo":MovingTo, "MovingDate":MovingDate, "creditpoint":creditpoint,"email":email,"name":name,"number":number,"distance":distance, "vehicle":Vehicle, };
        $.ajax({
            type:"post",
            url: path_v+"/otp/send-email.php",
            data: dataString,
            success: function(data) {
                //alert(city+"||"+shiftingType+"||"+ShiftingSize+"||"+HomeSize+"||"+Vehicle+"||"+ServiceQuality+"||"+origin_city+"||"+MovingFrom+"||"+MovingTo+"||"+MovingDate+"||"+creditpoint+"||"+office+"||"+email+"||"+name+"||"+number);
            }
        });
}

/**
 *   Discount condition Start ==>
 **/
sessionStorage.setItem('01', "January");
sessionStorage.setItem('02', "February");
sessionStorage.setItem('03', "March");
sessionStorage.setItem('04', "April");
sessionStorage.setItem('05', "May");
sessionStorage.setItem('06', "June");
sessionStorage.setItem('07', "July");
sessionStorage.setItem('08', "August");
sessionStorage.setItem('09', "September");
sessionStorage.setItem('10', "October");
sessionStorage.setItem('11', "November");
sessionStorage.setItem('12', "December");

function daysInMonth (month, year) {
    var a = new Date().getFullYear()
    // returns the current year
    return new Date(a, month, 0).getDate();
}

/** datepicker **/
$("#enquiry-form-2019 #custom-datepicker").datepicker({
    dateFormat: "dd-mm-yy",
    maxDate: "+2m", 
    minDate:"d",
    onSelect: function(dateText, inst, a) {
        var x = $('#enquiry-form-2019 #custom-datepicker').val();
        $('#enquiry-form-2019 .webform-component--moving-date .form-control').val(x);
        var date = $(this).datepicker('getDate');
        //$('#enquiry-form-2019 .webform-component--moving-date .form-control').val($.datepicker.formatDate('DD', date));
        var days = $.datepicker.formatDate('DD', date);
        sessionStorage.setItem('day_count', days);
        var diff = new Date() - $(this).datepicker("getDate");
        diff = Math.floor(diff / (1000 * 60 * 60 * 24) * -1) + 1;
        var value = a + '(' + diff + ' days)'
        console.log(diff);
        var car_date_count = $.datepicker.formatDate('MM dd', new Date());
        sessionStorage.setItem("curr_month_count",$.datepicker.formatDate('MM', new Date()));
        var suffix = car_date_count.match(/\d+/); // 123456
        console.log('car_date_count = '+suffix);
        sessionStorage.setItem('suffix', suffix);
        //$('#count').val(diff);
        sessionStorage.setItem("date_count", diff);
        var a = $('.webform-component--moving-date .form-control').val();
        arr = a.split('-');
        //console.log(arr);
        strFile1 = arr[arr.length-2];
        strFile2 = arr[arr.length-3];
        //console.log(strFile);
        var s_month = sessionStorage.getItem(strFile1);
        sessionStorage.setItem('selected_month', strFile1);
        sessionStorage.setItem('selected_month_day', strFile2);
        sessionStorage.setItem('strFile', s_month);
        $('#enquiry-form-2019 .page_break_next_btn4').click();
    }
      
});

var total_credit_point, 
credit_point,
cur_val, 
moving_type_city_var,
curr_moving_date_var,
moving_date_var,
this_val_pre, 
this_val,
month_var, 
totle_date_counter,
cur_month_var, 
day_limit_count,
this_val_total,
month_count_limit_var;

/* -VARIABLES- */
var within_ddiff_d1_const=40 , outside_ddiff_d1_const=30, day_diff_value=20, within_ddiff_d2_maxlimit=40, outside_ddiff_d2_maxlimit=30;
var within_city_day_count=15, outside_city_day_count=20, within_ddiff_d2_inc=4, outside_ddiff_d2_inc=3;
var within_ddiff_d1_inc_const=10, outside_ddiff_d1_inc_const=8;
sessionStorage.removeItem('total_val');

/**
 *  discount function 
 **/ 
$('#submit_otp').on('mouseenter', function(){
    var moving_type_city_var = localStorage.getItem('city');
    var month_var = sessionStorage.getItem('strFile');
    var cur_month_var = sessionStorage.getItem('curr_month_count');
    var totle_date_counter = sessionStorage.getItem('date_count');
    var credit_point = localStorage.getItem('credit_val');
    var day_limit_count = sessionStorage.getItem('suffix');//selected_month
    var month_have_days = daysInMonth(sessionStorage.getItem('selected_month'));
    var month_end_var = month_have_days - 7;
    var select_day_of_month = sessionStorage.getItem('selected_month_day');

if(cur_month_var != month_var){
    console.log(cur_month_var+" !== "+month_var);
    if(day_limit_count < day_diff_value){
        console.log(day_limit_count +'  <  '+day_diff_value);

        var this_val_pre = (day_diff_value - day_limit_count)+20;
        console.log(this_val_pre+"%");

        var this_val = (credit_point * this_val_pre)/ 100;
        console.log(this_val);

        this_val_total = credit_point - this_val;
        console.log("1st condition = "+this_val_total);
        sessionStorage.setItem('total_val',this_val_total);
    }
}else{
    sessionStorage.setItem('total_val',credit_point);
}
    
if(totle_date_counter > 15){
    if(moving_type_city_var === "Within City"){
        console.log("d2 = "+moving_type_city_var);
        
        if(totle_date_counter > within_city_day_count){
            cur_val = sessionStorage.getItem('total_val');
            console.log('total = '+cur_val);
        
            this_val_pre = (totle_date_counter - within_city_day_count)  * within_ddiff_d2_inc;
            console.log(this_val_pre+"%");
            
            if( this_val_pre >41){
                    this_val_pre=within_ddiff_d2_maxlimit;
                    console.log(this_val_pre+"%");
            }
            
            this_val = (cur_val * this_val_pre )/ 100;
            console.log('main_d2 = '+this_val);
        
            this_val_total = cur_val-this_val;
            console.log("creadit-point 2nd condition= "+this_val_total);
            sessionStorage.setItem('total_val', this_val_total);
        }
    }
    
    if(moving_type_city_var === "Outside City"){
        if(totle_date_counter > outside_city_day_count){
            console.log("d2 = "+moving_type_city_var);
            
            cur_val = sessionStorage.getItem('total_val');
            console.log('total = '+cur_val);
        
            this_val_pre = (totle_date_counter - outside_city_day_count)  * outside_ddiff_d2_inc;
            console.log(this_val_pre+"%");
            
            if( this_val_pre >31){
                    this_val_pre=outside_ddiff_d2_maxlimit;
                    console.log(this_val_pre+"%");
            }
            
            
            this_val = (cur_val * this_val_pre )/ 100;
            console.log('main_d2 = '+this_val);
        
            this_val_total = cur_val-this_val;
            console.log("creadit-point 2nd condition= "+this_val_total);
            sessionStorage.setItem('total_val', this_val_total);
        }
    }
    
    /*if(moving_type_city_var === "Internationally"){
        console.log("d2 = "+moving_type_city_var);
        
        if(totle_date_counter > inter_day_count){
            cur_val = sessionStorage.getItem('total_val');
            console.log('total = '+cur_val);
        
            this_val_pre = (totle_date_counter - inter_day_count)  * inter_city_inc;
            console.log(this_val_pre+"%");
            
            if( this_val_pre >31){
                    this_val_pre=inter_more_25;
                    console.log(this_val_pre+"%");
                }
            
            
            this_val = (cur_val * this_val_pre )/ 100;
            console.log('main_d2 = '+this_val);
        
            this_val_total = cur_val-this_val;
            console.log("creadit-point 2nd condition= "+this_val_total);
            sessionStorage.setItem('total_val', this_val_total);
        }
    }*/
}
    
if(totle_date_counter <= 5){
    cur_val = sessionStorage.getItem('total_val');
    
    if(moving_type_city_var === "Within City"){
        if(totle_date_counter <= 2){

        console.log(moving_type_city_var);
        console.log('total = '+cur_val);

        this_val_pre = within_ddiff_d1_const - ( totle_date_counter * within_ddiff_d1_inc_const);
        console.log('d1 = '+ this_val_pre+"%");
        /*if( this_val_pre > 41){
            this_val_pre=Within_var;
            console.log(this_val_pre+"%");
        }*/

        this_val = (cur_val * this_val_pre )/ 100;
        console.log("this_val = "+ this_val);

        this_val_total = cur_val - this_val;
        console.log("creadit-point 2nd condition= "+this_val_total);
        sessionStorage.setItem('total_val', this_val_total);
        }
        
    }
    
    if( moving_type_city_var === "Outside City"){
        if(totle_date_counter <= 3){
        console.log(moving_type_city_var);

        this_val_pre = outside_ddiff_d1_const- (totle_date_counter * outside_ddiff_d1_inc_const);
        console.log('this_val_pre = '+ this_val_pre+"%");
        
        /*if( this_val_pre >41){
            this_val_pre=outside_var;
            console.log(this_val_pre+"%");
        }*/

        this_val = (cur_val * this_val_pre )/ 100;
        console.log("main_d1 = "+ this_val);

        this_val_total = cur_val - this_val;
        console.log("creadit-point 2nd condition= "+this_val_total);
        sessionStorage.setItem('total_val', this_val_total);
        }
    }
    
    /*if( moving_type_city_var === "Internationally"){
        if(totle_date_counter <= 5){
        console.log(moving_type_city_var);

        this_val_pre = inter_var- (totle_date_counter * inc_d2_inc);
        console.log('d1 = '+ this_val_pre+"%");
        
        if( this_val_pre > 41){
            this_val_pre=inter_var;
            console.log(this_val_pre+"%");
        }
        
        this_val = (cur_val * this_val_pre )/ 100;
        console.log("main_d1 = "+ this_val);
        
        this_val_total = cur_val - this_val;
        console.log("creadit-point 2nd condition= "+this_val_total);
        
        sessionStorage.setItem('total_val', this_val_total);
        }
    }*/
}

if(month_end_var <  select_day_of_month){
    var credit_point = sessionStorage.getItem('total_val');
    console.log( credit_point);
    console.log("month end offer Start ="+month_end_var+" you selected date = "+select_day_of_month + ' offer end = ' + month_have_days);
    
    var month_end_cal = (8 - ( month_have_days -  select_day_of_month)) * 5; 
    console.log("month end discount = "+month_end_cal+"%");
    
    this_val = (credit_point * month_end_cal)/ 100;
    console.log('month end val = '+this_val);
    
    this_val_total = credit_point - this_val;
    console.log('total = '+this_val_total);
    sessionStorage.setItem('total_val', this_val_total);
    
    
}
if(select_day_of_month < 4){
    console.log("month start");
    var credit_point = sessionStorage.getItem('total_val');
    console.log( credit_point);
    
    var moth_start = (4 - select_day_of_month) * 10;
    console.log('month start discount = '+ moth_start+'%');
    
    this_val = (credit_point * moth_start) / 100;
    console.log(' month starting val -'+this_val);
    
    this_val_total = credit_point - this_val;
    console.log('total = '+this_val_total);
    sessionStorage.setItem('total_val', this_val_total);
    
}

if(sessionStorage.getItem("total_val") > 20){
    
    var credit_point = sessionStorage.getItem("total_val");
    var this_val_total = credit_point-(((credit_point - 20)/100) * credit_point * 0.7);
    console.log('last total = '+this_val_total);
    sessionStorage.setItem('total_val', this_val_total);
    
}
$('#enquiry-form-2019 .webform-component--credit-points .form-control').val(sessionStorage.getItem("total_val"));

var round = $('.webform-component--credit-points .form-control').val();
$('.webform-component--credit-points .form-control').val(Math.round(round));
console.log('the final value = '+round+" round number = "+Math.round(round));


});

/**
 *  custom form 
 **/
localStorage.removeItem('shifting_type');
localStorage.removeItem('distance_f1');

$('#enquiry-form-2019 #front_button').click(function(){
$('#enquiry-form-2019 .custom-form').remove();
$('#enquiry-form-2019').append('<div class="custom-form"><div class="custom-form-title"></div><div class="form-item custom-form-origin"><input type="text" class="form-control form-text custom-form-origin-text" placeholder="Origin City"><span><i class="glyphicon glyphicon-screenshot"></i></span></div><div class="form-item custom-form-destination"><input type="text" class="form-control form-text custom-form-destination-text" placeholder="Destination"></div><button class="custom-form-btn">To Continue <i class="glyphicon glyphicon-chevron-right"></i></button></div>');
var custom = $('#enquiry-form-2019 .webform-component--header-markup').html();
$('#enquiry-form-2019 .custom-form-title').html(custom);
var ori = $('#enquiry-form-2019 .webform-component--origin-city-api .form-control').val();
var des = $('#enquiry-form-2019 .webform-component--destination-api .form-control').val();
console.log(ori+' === '+des);

$('#enquiry-form-2019 .custom-form .custom-form-origin-text').val(ori);
$('#enquiry-form-2019 .custom-form .custom-form-destination-text').val(des);
$('#enquiry-form-2019 .custom-form').hide();



});


/*Banner Webform*/
$("#webform-client-form-2 div, .comp-item .book-now").on("click",function(){
    $('body').addClass('form-initiated');
    $('#enquiry-form-2019 .close-btn').remove();
    $('#enquiry-form-2019').prepend('<button class="close-btn"> X </button>');
});

$('#enquiry-form-2019').on("mousemove", function(){
$('#enquiry-form-2019 .close-btn').click(function(){
    $('body').removeClass('form-initiated');
    $('#enquiry-form-2019 .close-btn').remove(); 
    
if(localStorage.getItem('distance_f1') !== null){
    //console.log('click distance_f1');
    $('#enquiry-form-2019 .custom-form').show();
    $('#enquiry-form-2019 #webform-client-form-2').hide();
    //$('body').removeClass('form-initiated');
    //$('#enquiry-form-2019 .close-btn').remove(); 
    
}

if(localStorage.getItem('shifting_type') !== null){//<div><strong>Moving Type:</strong><span class="custom-form-moving-type"></span></div>

//console.log('click shifting_type');
$('#enquiry-form-2019 .custom-form .custom-form-moving-type').text(localStorage.getItem('shifting_type'));

$('#enquiry-form-2019 .custom-form').show();
$('#enquiry-form-2019 #webform-client-form-2').hide();
}
});
});
$('#enquiry-form-2019').on("mousemove",function(){
$('#enquiry-form-2019 .custom-form').click(function(){
    //console.log('custom-form-btn');
    $('body').addClass('form-initiated');
    $('#enquiry-form-2019 .close-btn').remove();
    $('#enquiry-form-2019').prepend('<button class="close-btn"> X </button>');
    $('#enquiry-form-2019 #webform-client-form-2').show();
    $('#enquiry-form-2019 .custom-form').hide();
    
});   
});

   
});//end of main document function