var $ = jQuery;

jQuery(document).ready(function($) {
    
/*Testimonial show more*/
$(".show-more-testimonial").click(function(){
    $(".testimonial-section .more-content").remove();
    $(".testimonial-section").addClass("more-content");
    $('.testimonial-section').prepend('<button class="testimonial-close-btn"> X </button>');
    $('body').addClass('testimonial-initiated');
});
$('.show-more-testimonial').hover( function(){
    $(".testimonial-close-btn").click(function(e){
    e.preventDefault();
    $('body').removeClass('testimonial-popup');
    $(".testimonial-section").removeClass("more-content");
    $('.testimonial-close-btn').remove();
    $('body').removeClass('testimonial-initiated');
    
});
});

 /*Nav Button Click for open*/
$("#navFormButton").click(function(){
        $("#nav-myForm").show();
});
/*Nev bar book now form*/
$("#navFormButton").on("click",function(){
    $('body').addClass('callback-form-initiated');
    $("#nav-myForm").show();
    $('.callback-close-btn').remove();
    $('#nav-myForm').prepend('<button class="callback-close-btn"> X </button>');
});
$('#navFormButton').hover( function(){
    $(".callback-close-btn").click(function(e){
    e.preventDefault();
    $('body').removeClass('callback-form-initiated');
    $('.callback-close-btn').remove();
    $("#nav-myForm").hide();
    
});
});

 /*slideshow only in mobile*/
        const init = {
		autoplay: true,
		infinite: true,
		cssEase: "linear",
		slidesToShow: 1,
		slidesToScroll: 1 };


		$(() => {
		  const win = $(window);
		  const slider = $(".slider");
		  win.on("load resize", () => {
		    if (win.width() < 480) {
		      slider.not(".slick-initialized").slick(init);
		    } else if (slider.hasClass("slick-initialized")) {
		      slider.slick("unslick");
		    }
		  });
		});
    
/* Show more with class more */
    // Configure/customize these variables.
    var showChar = 100; // How many characters are shown by default
    var ellipsestext = "...";
    var moretext = "Show more >";
    var lesstext = "Show less";
    

    $('.more').each(function() {
        var content = $(this).html();
 
        if(content.length > showChar) {
 
            var c = content.substr(0, showChar);
            var h = content.substr(showChar, content.length - showChar);
 
            var html = c + '<span class="moreellipses">' + ellipsestext+ '&nbsp;</span><span class="morecontent"><span>' + h + '</span>&nbsp;&nbsp;<a href="" class="morelink">' + moretext + '</a></span>';
 
            $(this).html(html);
        }
 
    });
 
    $(".morelink").click(function(){
        if($(this).hasClass("less")) {
            $(this).removeClass("less");
            $(this).html(moretext);
        } else {
            $(this).addClass("less");
            $(this).html(lesstext);
        }
        $(this).parent().prev().toggle();
        $(this).prev().toggle();
        return false;
    });


/*slide show client*/

    $('.carousel').carousel({
      interval: 6000
    });


/*------------------------vartical Tab--------------------------*/
$('#menu li').on('click', function(){
    $('#menu li').removeClass('active');
    $(this).addClass('active');
});
$("#menu li a").on('click', function(e) {
		        e.preventDefault()
		        var page = $(this).data('page');
		        $("#pages .page:not('.hide')").stop().fadeOut('fast', function() {
		            $(this).addClass('hide');
		            $('#pages .page[data-page="'+page+'"]').fadeIn('slow').removeClass('hide');
		        });
		    });

/*---------------Accordion Toggle------------------*/
function toggleIcon(e) {
        $(e.target)
            .prev('.panel-heading')
            .find(".more-less")
            .toggleClass('glyphicon-chevron-right glyphicon-chevron-down');
    }
    $('.panel-group').on('hidden.bs.collapse', toggleIcon);
    $('.panel-group').on('shown.bs.collapse', toggleIcon);



/*-------------------------on scroll counter-----------------------*/
if(window.location.pathname === '/'){

/*Home Banner slide Show*/
$('#home-banner-slideshow').slick({
		  autoplay: true,
		  dots: true,
		  autoplaySpeed: 3000
		});
$('#home-client-block').slick();


var a = 0;
$(window).scroll(function() {

  var oTop = $('.counter-grid-item').offset().top - window.innerHeight;
  if (a === 0 && $(window).scrollTop() > oTop) {
    $('.timer').each(function() {
      var $this = $(this),
        countTo = $this.attr('data-count');
      $({
        countNum: $this.text()
      }).animate({
          countNum: countTo
        },

        {

          duration: 3000,
          easing: 'swing',
          step: function() {
            $this.text(Math.floor(this.countNum));
          },
          complete: function() {
            $this.text(this.countNum);
            //alert('finished');
          }

        });
    });
    a = 1;
  }
});
}

/*Cut Pest Summery*/
    $(".node-type-pm-search-page .lower-half .radix-layouts-content").html($(".node-type-pm-search-page .upper-half .radix-layouts-content .summery"));
    $(".node-type-pm-search-page .upper-half .radix-layouts-content .summery").hide;
/*Change the Webform Heading*/
    $(".node-type-pm-search-page #webform-client-form-2 .webform-component--header-markup h2").html("Hire Now");

/*Show More Less with height*/
	$('.above-content-wrapper span.read-more').click(function(){
	    var $this = $(this);
	    var textu = $('.above-content-wrapper span.read-more').text();
		if(textu === 'Read More'){
		    console.log('more');
		    $('.above-content-inner').removeClass('hide-content');
		    $('.above-content-inner').addClass('show-content');
		    $('.above-content-wrapper span.read-more').text('Read Less');
		    textu = $('.above-content-wrapper span.read-more').text();
		}

		else if(textu === 'Read Less'){
		    console.log('less');
		    $('.above-content-inner').removeClass('show-content');
		    $('.above-content-inner').addClass('hide-content');
		    $('.above-content-wrapper span.read-more').text('Read More');
		    textu = $('.above-content-wrapper span.read-more').text();

		}
	});
	
/*Fetching the width of testimonial section*/
var width_test = $(".tetimonial-item").width();
$('.testimonial-section .view-content').css('width', width_test);




});//main jQuery function